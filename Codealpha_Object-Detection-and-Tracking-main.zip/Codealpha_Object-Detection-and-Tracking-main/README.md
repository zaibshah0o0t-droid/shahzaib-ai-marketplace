# Codealpha_Object-Detection-and-Tracking
🎯 YOLOv8 Object Tracking Pro is a Python Tkinter app for real-time object detection and tracking. Supports webcam &amp; video files, multiple YOLOv8 models, ByteTrack/BoT-SORT trackers, adjustable confidence, FPS display, and a modern GUI with scrollable video playback.
